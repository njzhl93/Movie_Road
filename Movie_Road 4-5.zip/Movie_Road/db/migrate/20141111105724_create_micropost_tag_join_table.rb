class CreateMicropostTagJoinTable < ActiveRecord::Migration
  def change
  end
end
