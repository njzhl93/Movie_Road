require 'spec_helper'

describe Relationship do
  pending "add some examples to (or delete) #{__FILE__}"
end
