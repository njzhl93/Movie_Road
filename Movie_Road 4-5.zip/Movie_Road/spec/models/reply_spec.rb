require 'spec_helper'

describe Reply do
  pending "add some examples to (or delete) #{__FILE__}"
end
