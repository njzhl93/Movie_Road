require 'spec_helper'

describe SearchesController do

end
